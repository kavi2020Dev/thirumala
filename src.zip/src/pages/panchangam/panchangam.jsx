import React from 'react'

const Panchangam = () => {
  return (
    <div>Panchangam</div>
  )
}

export default Panchangam