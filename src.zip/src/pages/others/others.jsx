import React from 'react'

const Others = () => {
  return (
    <div>Others</div>
  )
}

export default Others