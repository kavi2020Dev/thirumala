import React from 'react'

const TempleHistory = () => {
  return (
    <div>TempleHistory</div>
  )
}

export default TempleHistory