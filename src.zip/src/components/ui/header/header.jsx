import i18next from "i18next";
import React, { lazy, useState } from "react";
import { useTranslation } from "react-i18next";
import "./index.css";
import Background from "../../../assets/images/png/background.png";
import Sec_content from "./submodule/sec_content";
import First_Content from "./submodule/first_content";
import Third_content from "./submodule/third_content";
import { motion } from "framer-motion";
import { useLocation } from "react-router-dom";
import MenuOutlinedIcon from '@mui/icons-material/MenuOutlined';
import { IconButton, Typography, useMediaQuery, useTheme } from "@mui/material";

const Header = () => {
  const { t } = useTranslation();
  const [isActive, setIsActive] = useState(true);
  const theme = useTheme()
  const [isMove, setIsMove] = useState(false);
  const isResponsive = useMediaQuery(theme.breakpoints.down('768'))
  const location = useLocation()
  const isMainContent = Boolean(location.pathname == '/home') || location.pathname == '/'

  const onLanguageChange = (lang) => {
    if (lang == "ta") {
      setIsActive(false);
    } else {
      setIsActive(true);
    }
    i18next.changeLanguage(lang);
  };

  console.log(isResponsive);

  return (
    <>
      <motion.div className='relative bg-primary flex items-center cursor-pointer'>
        {/* Lanuage converter */}
        <div className='bg-gradient-p-s w-fit flex items-center p-5 opacity-95'>
         {isResponsive ? <IconButton size="small"><MenuOutlinedIcon sx={{color:'white'}}/></IconButton> : 
           <>
            <motion.div
            onClick={() => onLanguageChange("ta")}
            whileHover={{scale:1.1}}
            whileTap={{ scale:1.0}}
            className={
              isActive
                ? "p-2 rounded-25 px-10 ml-12 items-center text-white cursor-pointer"
                : "bg-yellow-500 p-3 rounded-25 px-10 items-center flex cursor-pointer"
             }
            >
            {!isActive && (
              <svg
                width='13'
                height='13'
                viewBox='0 0 13 13'
                fill='none'
                xmlns='http://www.w3.org/2000/svg'
              >
                <path
                  d='M5.34198 7.93735L3.06801 5.45318L2.95256 5.42839C1.60898 5.13984 0.404251 6.31104 0.65477 7.66222L4.34408 11.6926C5.04115 12.4541 6.27657 12.3221 6.79704 11.4305L12.5522 1.57193C13.0274 0.757915 11.8983 -0.0287562 11.2993 0.699021L5.34198 7.93735Z'
                  fill='#158219'
                />
              </svg>
            )}
            <p className={`text-5 ${isActive ? "font-normal" : "font-bold"}`}>
              தமிழ்
            </p>
          </motion.div>
          
          <motion.div
            onClick={() => onLanguageChange("en")}
            animate={{x:5}}
            whileHover={{scale:1.1}}
            whileTap={{ scale:1.0}}
            className={
              !isActive
                ? "p-2 rounded-25 px-10 ml-12 items-center text-white cursor-pointer"
                : "bg-yellow-500 p-3 rounded-25 px-10 items-center align-middle flex cursor-pointer"
             }
            >
            {isActive && (
              <svg
                width='13'
                height='13'
                viewBox='0 0 13 13'
                fill='none'
                xmlns='http://www.w3.org/2000/svg'
              >
                <path
                  d='M5.34198 7.93735L3.06801 5.45318L2.95256 5.42839C1.60898 5.13984 0.404251 6.31104 0.65477 7.66222L4.34408 11.6926C5.04115 12.4541 6.27657 12.3221 6.79704 11.4305L12.5522 1.57193C13.0274 0.757915 11.8983 -0.0287562 11.2993 0.699021L5.34198 7.93735Z'
                  fill='#158219'
                />
              </svg>
            )}
            <p className={`text-5 ${!isActive ? "font-normal" : "font-bold"} pt-2`}>
              English
            </p>
          </motion.div>
           </>
          } 
        </div>

        <div onMouseEnter={() => setIsMove(true)}
         onMouseLeave={() => setIsMove(false)}
         className="overflow-hidden whitespace-nowrap w-full items-center"
         style={{ display: 'inline-block'}} 
        >
          {isMove ? (
        <motion.div
          animate={{ x: ['100%', '-100%'] }}
          className="items-center"
          transition={{
            repeat: Infinity,
            duration:20,
            ease: 'linear',
          }}
        >
       <Typography className="text-white" variant="h5">{t("header.title")}</Typography>   
       </motion.div>
      ) : (
       <motion.div initial={{ x: '0' }} transition={{duration:20}}>        
        <Typography className="text-white" variant="h5">{t("header.title")}</Typography>   
       </motion.div> 
       )} 
        
       </div>
       </motion.div>

      {isMainContent ? <div
        style={{ backgroundImage: `url(${Background})` }}
        className='w-full h-screen bg-cover bg-center flex justify-between p-10'
       >
        <First_Content />
        <Sec_content />
        <Third_content />
      </div> : null}
    </>
  );
};

export default Header;
