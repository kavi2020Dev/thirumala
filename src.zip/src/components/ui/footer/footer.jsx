import React from 'react'
import Background from '../../../assets/images/png/footer.png'
import Youtube from '../../../assets/images/png/yt.png'
import Fb from '../../../assets/images/png/fb.png'
import Insta from '../../../assets/images/png/insta.png'
import X from '../../../assets/images/png/x.png'
import { useTranslation } from 'react-i18next'

const Footer = () => {
 const { t } = useTranslation()

  return (
   <>
    <div className='relative'>
     <div className='bg-gradient-p-s h-48 flex justify-between pl-56'>
      <div className=''>1</div>   
      <div className=''>2</div>   
     </div> 

     <div className='bg-primary w-full p-10 pl-56 items-end flex'>
      <img src={Youtube} className='w-7 h-7 cursor-pointer mx-8'/>  
      <img src={Fb} className='w-7 h-7 cursor-pointer mx-8'/>  
      <img src={Insta} className='w-7 h-7 cursor-pointer mx-8'/>  
      <img src={X} className='w-7 h-7 cursor-pointer mx-8'/>  
      <h6 className='text-white ml-5'>{t('footer.name')}</h6>   
     </div> 

     <img src={Background} alt='templ' className='w-48 h-auto z-1 absolute bottom-1 left-5'/>
    </div>
   </> 
  )
}

export default Footer